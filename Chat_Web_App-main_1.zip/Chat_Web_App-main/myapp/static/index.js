// Move javascript here and make necessary changes and adjustment
